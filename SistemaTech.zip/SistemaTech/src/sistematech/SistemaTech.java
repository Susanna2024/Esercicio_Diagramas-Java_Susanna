/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistematech;

import java.util.*; // Importaciones generales para utilidades
import java.time.LocalDate;


public class SistemaTech {
    private int id;

    public static void main(String[] args) {
        // Punto de entrada para el programa
        System.out.println("Bienvenido a SistemaTech!, Reserva tu sala :3");

        // Creaci�n de instancias para probar el sistema

        // Usuarios y sus subclases
        Usuario usuario = new Usuario("Juan", "Rossi", "Cliente", 1, "juan@example.com", "password123");
        System.out.println( "Login: " + usuario.getUsuario() );
        
        // Salas

        Sala sala = new Sala(1, 50.0f, 10, true, "Ubicaci�no", null, "Sala de conferencias"); // Crear una instancia de Sala

// Creacion de reserva
Reserva reserva = new Reserva(
    14567,  // ID reserva
    LocalDate.of(2024, 4, 27),  // inicio con LocalDate
    LocalDate.of(2024, 4, 27),  // fin 
    12,  // hora
    15,  // hra fin
    sala,  // sala
    50.24f,  // Precio
    "Completado",  // estado
    "5678"  // Codigo reserva
);
 System.out.println( "Tu sala: " + sala.getDescripcion() );
        System.out.println( "" + reserva.getReservaInfo() );
 
   


         // Crear un equipamiento 
        Equipamiento equipamiento = new Equipamiento(1, 1, 0); // ID, proyector, sistema de video
System.out.println( "Equipamiento selecionado con id: " + equipamiento.getId() );
     
       

       
        
// Pagos
        Pago pago = new Pago(1, "Pago con tarjeta");
System.out.println(pago.getDatosPago() );

    }
}
