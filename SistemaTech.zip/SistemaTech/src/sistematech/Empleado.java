/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistematech;
import java.util.*;

/**
 *
 * @author Susanna
 */
class Empleado extends Cliente {
//costructor
    public Empleado(String nombre, String apellidos, String rol, int id, String mail, String contrasena, int telefono) {
        super(nombre, apellidos, rol, id, mail, contrasena,telefono);
      
    }
}





  