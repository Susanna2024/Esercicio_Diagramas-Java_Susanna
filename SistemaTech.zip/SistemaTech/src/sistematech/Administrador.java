/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistematech;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Susanna
 */
// Subclase Administrador
class Administrador extends Usuario {
    public Administrador(String nombre, String apellidos, String rol, int id, String mail, String contrasena) {
        super(nombre, apellidos, rol, id, mail, contrasena);
    }

    public List<Reportes> consultarReportes() {
        // L�gica para consultar reportes
        return new ArrayList<>(); // Retorna una lista de reportes
    }


    public boolean modificarEquipamiento(int id) {
        // L�gica para modificar equipamiento
        return true; // Retorna true si el cambio fue exitoso
    }

    public void eliminarEquipamiento(int id) {
        // L�gica para eliminar equipamiento
    }
}
