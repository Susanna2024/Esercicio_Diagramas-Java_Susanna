/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistematech;

/**
 *
 * @author Susanna
 */
// Subsubclase Cliente_Externo
class Cliente_Externo extends Cliente {
    public Cliente_Externo(String nombre, String apellidos, String rol, int id, String mail, String contrasena, int telefono) {
        super(nombre, apellidos, rol, id, mail, contrasena, telefono);
    }
}
