/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistematech;

import java.util.*;



// Clase Usuario
public class Usuario {
    private String nombre;
    private String apellidos;
    private String rol;
    private int id;
    private String mail;
    private String contrasena;

    public Usuario(String nombre, String apellidos, String rol, int id, String mail, String contrasena) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.rol = rol;
        this.id = id;
        this.mail = mail;
        this.contrasena = contrasena;
    }

    public boolean iniciarSesion(String mail, String contrasena) {
        // Validar credenciales con la clase Autenticacion
        Autenticacion autenticacion = new Autenticacion(1, this.id, this.mail, this.contrasena, this.rol);
        return autenticacion.validarCredenciales(mail, contrasena);
    }

    public void cerrarSesion() {
        // L�gica para cerrar sesi�n
    }

  // Metodo getter per il campo "Usuario"
    public String getUsuario() {
    return nombre + " " + apellidos + " (" + mail + ")";  
}

}







